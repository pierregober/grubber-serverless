module.exports = {
  PLAID_CLIENT_ID: '60f0f6a9ffd78d000f47e32c',
  PLAID_SECRET: '32f89b1ae5efe1d1a1072c2f650299'
};
